package ques1and2;

import java.util.Scanner;

public class Eggs {
	public void calculate(int eggs) {
		int gross = eggs / 144;
		int dozen = (eggs % 144) / 12;
		int remaining = ((eggs % 144) % 12);
		System.out.println("Your number of eggs is " + gross + " Gross, " + dozen + " dozen, and " + remaining);
	}

	public static void main(String[] args) {
		System.out.println("Enter no.of eggs");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		Eggs out = new Eggs();
		out.calculate(a);

	}

}
