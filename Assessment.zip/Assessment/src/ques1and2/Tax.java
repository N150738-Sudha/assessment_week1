package ques1and2;

import java.util.Scanner;

public class Tax {
	public void tax1(int gender, int income) {
		if (income <= 500000)
			if (gender == 1) {
				if (income >= 0 && income <= 180000)
					System.out.println(0);
				else if (income >= 180001 && income <= 500000)
					System.out.println("Tax is :" + income * 0.1);
				else
					System.out.println("Enter positive income");
			} else if (gender == 2) {
				if (income >= 0 && income <= 190000)
					System.out.println(0);
				else if (income >= 190001 && income <= 500000)
					System.out.println("Tax is :" + income * 0.1);
				else
					System.out.println("Enter positive income");
			} else {
				System.out.println("Enter correct gender");
			}
		else if (income >= 500001 && income <= 800000)
			System.out.println("Tax is :" + income * 0.2);
		else if (income > 800000)
			System.out.println("Tax is :" + income * 0.3);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number if gender is male and 2 for female \n Enter your income");
		int genderNumber = sc.nextInt();
		int income = sc.nextInt();
		Tax out = new Tax();
		out.tax1(genderNumber, income);
	}

}
