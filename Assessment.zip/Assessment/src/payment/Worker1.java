package payment;

interface Worker1 {
	int pay(int weeks);
}

class DailyWorker implements Worker1 {
	int wagePerDay = 100;

	public int pay(int days) {
		return days * wagePerDay;

	}

}

class SalariedWorker implements Worker1 {
	int salaryPerWeek = 1000;

	public int pay(int weeks) {
		return weeks * salaryPerWeek;
	}

}
