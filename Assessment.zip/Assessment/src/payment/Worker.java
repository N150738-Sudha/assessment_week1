package payment;

class Worker {
	String name;
	int daysOrWeeks;
	String workerType;

	public Worker(String name, int daysOrWeeks, String workerType) {
		super();
		this.name = name;
		this.daysOrWeeks = daysOrWeeks;
		this.workerType = workerType;
	}

	@Override
	public String toString() {
		return "Worker [name=" + name + ", salary=" + getSalary() + ", workerType=" + workerType + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		if (workerType == "D") {
			DailyWorker d = new DailyWorker();
			int salary = d.pay(daysOrWeeks);
			return salary;
		} else if (workerType == "W") {
			SalariedWorker s = new SalariedWorker();
			int salary = s.pay(daysOrWeeks);
			return salary;
		}
		return 0;
	}

	public void setSalary(int days) {
		this.daysOrWeeks = days;
	}

	public String getWorkerType() {
		return workerType;
	}

	public void setWorkerType(String workerType) {
		this.workerType = workerType;
	}

}
