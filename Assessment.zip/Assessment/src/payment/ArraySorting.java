package payment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArraySorting {

	public static void main(String[] args) {
		Worker w1 = new Worker("Rani", 13, "D");
		List<Worker> workers = new ArrayList<Worker>();
		workers.add(w1);
		workers.add(new Worker("Bhavani", 2, "W"));
		workers.add(new Worker("Kavya", 5, "W"));
		workers.add(new Worker("Sai", 14, "D"));
		workers.add(new Worker("Sankar", 1, "W"));

		Iterator<Worker> iterator = workers.iterator();
		System.out.println("Before Sorting....");
		while (iterator.hasNext()) {
			Worker temp = iterator.next();
			System.out.println(temp);
		}

		Collections.sort(workers, new SalaryComparator());
		Iterator<Worker> iterator1 = workers.iterator();
		System.out.println("1. After sorting by WorkerSalary - using Comparable");
		while (iterator1.hasNext()) {
			Worker temp = iterator1.next();
			System.out.println(temp);
		}

	}

}
