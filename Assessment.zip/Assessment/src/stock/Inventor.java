package stock;

public class Inventor {
	int quantity;
	int lowOrderLevelQuantity;
}
